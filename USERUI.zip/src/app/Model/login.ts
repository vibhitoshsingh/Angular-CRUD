export class Login{
    Id: number;
    Email: string;
    Password: string;
}