export class Register
{
    id:number;
    Email:string;
    Password:string;
}