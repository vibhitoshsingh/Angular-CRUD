export class User {
        id: number;
        name:string;
        job:string;
        
}
