import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from "@angular/router";
import { FormControl, FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { User } from "../Model/User";
import { UserService } from "../userservices/user.service";


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  editMode:boolean;
  Id:number;
  userForm: FormGroup;
  currentUser;
  imageName='';

  constructor(private activatedRoute: ActivatedRoute,private userService:UserService,private fb: FormBuilder,private router:Router) { }

  ngOnInit() {
     this.activatedRoute.params.subscribe(
      (params: Params) => {
               this.Id = params['id'];
               //console.log(this.studentId);
               if(this.Id!= undefined) {
                 this.editMode=true;
                 this.userService.getUserById(this.Id).subscribe(data => {
                      this.currentUser = data;
                      this.createForm();
                    });
                 
               } else {
                 this.editMode=false;
                 this.createForm();
               }
               
      }
    );
  }

createForm() {
   let name = '';
    let job = '';
    

    if (this.editMode) {
      const user:User = this.currentUser;
       name = !user?name: user.name ;
       job = !user?job: user.job ;
     
     }
 
     this.userForm = new FormGroup({
      'name' : new FormControl(name),
      'job' : new FormControl(job),
 
         });

      }


       onSubmit() {


    this.currentUser = this.prepareDataBeforeSave();
    
         this.userService.saveUser(this.currentUser).subscribe(data => {
          this.router.navigate(['user-listing'])
        });

     
    
    this.ngOnInit();
  }
   
    
    prepareDataBeforeSave() : User {
      const formModel = this.userForm.value;
      let id:number;
      if(this.editMode==false) {
        id =0;
      }else {
        id=this.Id;
      }
    
     console.log(formModel);
     const saveUser:User = {
        id:id,
        name: formModel.name,
        job:formModel.job,
      
      };
     return saveUser;
   }
  
}
