import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { UserService } from "../../userservices/user.service";

@Component({
  selector: 'app-user-listing',
  templateUrl: './user-listing.component.html',
  styleUrls: ['./user-listing.component.css']
})
export class UserListingComponent implements OnInit {
results:any = '';
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {
    this.getAllUsers();
  }
   getAllUsers() {
    this.userService.UserListing().subscribe(data => {
      console.log('data', data);
      this.results='';
      this.results = data;
   });
  }

 editUser(id) {
     this.router.navigate(['/home/editUser',id])
  }
Ondelete(id){
  this.userService.DeleteUser();
}
}
